CREATE DATABASE Rental_db;

CREATE TABLE public.usuario (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  nome character varying NOT NULL,
  cpf character varying,
  email character varying,
  senha character varying,
  CONSTRAINT usuario_pkey PRIMARY KEY (id)
);
CREATE TABLE public.equipamentos (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  nome character varying NOT NULL,
  marca character varying,
  modelo character varying,
  cor character varying,
  categoria character varying,
  potencial integer,
  material character varying,
  peso numeric,
  dimensao character varying,
  quantidade_disponivel numeric,
  quantidade_minima numeric,
  CONSTRAINT equipamentos_pkey PRIMARY KEY (id)
);
CREATE TABLE public.movimentar (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  data_pedido date NOT NULL DEFAULT CURRENT_DATE,
  data_fim date,
  data_inicio date,
  quantidade numeric,
  observacao character varying,
  tipo character varying,
  usuario_id bigint,
  equipamento_id bigint,
  CONSTRAINT movimentar_pkey PRIMARY KEY (id),
  CONSTRAINT movimentar_usuario_fk FOREIGN KEY (usuario_id) REFERENCES public.usuario(id),
  CONSTRAINT movimentar_equipamento_fk FOREIGN KEY (equipamento_id) REFERENCES public.equipamentos(id)
);