package com.senai.backend.rental_eventos.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senai.backend.rental_eventos.models.Movimentar;

public interface MovimentarRepository extends JpaRepository<Movimentar, Integer> {
    
    boolean existsByEquipamentoId(Integer id_equipamento);

    List<Movimentar> findByEquipamentoIdOrderByDataPedidoDesc(Integer idEquipamento);
}
