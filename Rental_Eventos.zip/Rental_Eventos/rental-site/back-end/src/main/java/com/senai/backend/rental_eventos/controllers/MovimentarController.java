package com.senai.backend.rental_eventos.controllers;

import java.math.BigInteger;
import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.senai.backend.rental_eventos.models.Usuario;
import com.senai.backend.rental_eventos.services.MovimentarService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/movimentar")
public class MovimentarController {
    
    private  final MovimentarService ms;

    public MovimentarController(MovimentarService ms) {
        this.ms = ms;
    }

    
    @PostMapping
    public String movimentar(
            @RequestParam Integer id_equipamento,
            @RequestParam String tipo,
            @RequestParam BigInteger quantidade,
            @RequestParam(required = false) String observacao,
            @RequestParam LocalDate data_pedido,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");

        if (usuario == null) {
            return "redirect:/login";
        }

        try {

            ms.movimentar(
                id_equipamento,
                tipo,
                quantidade,
                observacao,
                data_pedido,
                data_pedido,
                null,
                usuario
            );

            return "redirect:/equipamentos/detalhes/" + id_equipamento;

        } catch (RuntimeException e) {

            redirectAttributes.addFlashAttribute("erro", e.getMessage());
            
            return "redirect:/equipamentos/detalhes/" + id_equipamento;
        }
        
    }
    
}
