package com.senai.backend.rental_eventos.models;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "equipamentos")
public class Equipamentos {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "nome")
    @NotBlank(message = "O nome é obrigatório")
    private String nome;

    @Column(name = "marca")
    private String marca;

    @Column(name = "modelo")
    private String modelo;

    @Column(name = "cor")
    private String cor;

    @Column(name = "categoria")
    private String categoria;

    @Column(name = "potencial")
    private Integer potencial;

    @Column(name = "material")
    private String material;

    @Column(name = "peso")
    private BigDecimal peso;

    @Column(name = "dimensao")
    private String dimensao;

    @Column(name = "quantidade_disponivel")
    @NotNull(message = "A quantidade disponível é obrigatória")
    @Min(value = 1, message = "A quantidade deve ser maior que zero")
    private BigInteger quantidadeDisponivel;

    @Column(name = "quantidade_minima")
    @NotNull(message = "A quantidade mínima é obrigatória")
    @Min(value = 1, message = "A quantidade deve ser maior que zero")
    private BigInteger quantidadeMinima;

    @OneToMany(mappedBy = "equipamento")
    private List<Movimentar> movimentar;

    //Constructor default
    public Equipamentos() {
    }

    //Constructor parametrizado
    public Equipamentos(Integer id, String nome, String marca, String modelo, String cor, String categoria, Integer potencial, String material, BigDecimal peso, String dimensao, BigInteger quantidadeDisponivel, BigInteger quantidadeMinima, List<Movimentar> movimentar) {
        this.id = id;
        this.nome = nome;
        this.marca = marca;
        this.modelo = modelo;
        this.cor = cor;
        this.categoria = categoria;
        this.potencial = potencial;
        this.material = material;
        this.peso = peso;
        this.dimensao = dimensao;
        this.quantidadeDisponivel = quantidadeDisponivel;
        this.quantidadeMinima = quantidadeMinima;
        this.movimentar = movimentar;
    }

    //Getters e Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public Integer getPotencial() {
        return potencial;
    }

    public void setPotencial(Integer potencial) {
        this.potencial = potencial;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public BigDecimal getPeso() {
        return peso;
    }

    public void setPeso(BigDecimal peso) {
        this.peso = peso;
    }

    public String getDimensao() {
        return dimensao;
    }

    public void setDimensao(String dimensao) {
        this.dimensao = dimensao;
    }

    public BigInteger getQuantidadeDisponivel() {
        return quantidadeDisponivel;
    }

    public void setQuantidadeDisponivel(BigInteger quantidadeDisponivel) {
        this.quantidadeDisponivel = quantidadeDisponivel;
    }

    public BigInteger getQuantidadeMinima() {
        return quantidadeMinima;
    }

    public void setQuantidadeMinima(BigInteger quantidadeMinima) {
        this.quantidadeMinima = quantidadeMinima;
    }

    public List<Movimentar> getMovimentar() {
        return movimentar;
    }

    public void setMovimentar(List<Movimentar> movimentar) {
        this.movimentar = movimentar;
    }
}
