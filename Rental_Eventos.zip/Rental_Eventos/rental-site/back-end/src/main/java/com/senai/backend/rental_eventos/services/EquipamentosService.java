package com.senai.backend.rental_eventos.services;

import java.util.Comparator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.senai.backend.rental_eventos.models.Equipamentos;
import com.senai.backend.rental_eventos.repositories.EquipamentosRepository;
import com.senai.backend.rental_eventos.repositories.MovimentarRepository;

@Service
public class EquipamentosService {
    
    private final EquipamentosRepository er;
    private final MovimentarRepository mr;

    public EquipamentosService(EquipamentosRepository er, MovimentarRepository mr) {
        this.er = er;
        this.mr = mr;
    }

    public List<Equipamentos> listarTodos() {
        return er.findAll();
    }

    public List<Equipamentos> buscarPorNome(String nome) {
        return er.findByNomeContainingIgnoreCase(nome);
    }

    public Equipamentos salvar(Equipamentos equipamentos) {
        return er.save(equipamentos);
    }

    public Equipamentos buscarPorId(Integer id_equipamento) {

        return er.findById(id_equipamento)
                .orElseThrow(() ->
                    new RuntimeException("Equipamento não encontrado"));
    }

    public void excluir(Integer id) {
        
        if (mr.existsByEquipamentoId(id)) {
            throw new RuntimeException(
                "Não é possível excluir este equipamento, pois ele possui movimentações registradas.");
        }
        
        er.deleteById(id);
    }

    public List<Equipamentos> listarOrdenado() {

        List<Equipamentos> equipamento = er.findAll();

        equipamento.sort(
            Comparator.comparing(Equipamentos::getNome,
                String.CASE_INSENSITIVE_ORDER)
        );

        return equipamento;
    }
}
