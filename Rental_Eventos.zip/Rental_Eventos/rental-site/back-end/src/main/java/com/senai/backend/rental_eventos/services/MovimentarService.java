package com.senai.backend.rental_eventos.services;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.senai.backend.rental_eventos.models.Equipamentos;
import com.senai.backend.rental_eventos.models.Movimentar;
import com.senai.backend.rental_eventos.models.Usuario;
import com.senai.backend.rental_eventos.repositories.EquipamentosRepository;
import com.senai.backend.rental_eventos.repositories.MovimentarRepository;

@Service
public class MovimentarService {
    
    private final MovimentarRepository mr;
    private final EquipamentosRepository er;

    public MovimentarService(MovimentarRepository mr, EquipamentosRepository er) {
        this.mr = mr;
        this.er = er;
    }

    public List<Movimentar> listarPorEquipamento(Integer idEquipamento) {
    return mr.findByEquipamentoIdOrderByDataPedidoDesc(idEquipamento);
    }

    @Transactional
    public String movimentar(
            Integer idEquipamento,
            String tipo,
            BigInteger quantidade,
            String observacao,
            LocalDate data_pedido,
            LocalDate data_inicio,
            LocalDate data_fim,
            Usuario usuario) {

        Equipamentos equipamento =
                er.findById(idEquipamento)
                    .orElseThrow(() ->
                        new RuntimeException(
                            "Equipamento não encontrado"));

        if (quantidade == null ||
                quantidade.compareTo(BigInteger.ZERO) <= 0) {

            throw new RuntimeException(
                "A quantidade deve ser maior que zero.");
        }

        if (tipo.equalsIgnoreCase("ENTRADA")) {

            equipamento.setQuantidadeDisponivel(
                equipamento.getQuantidadeDisponivel()
                    .add(quantidade)
            );

        } else if (tipo.equalsIgnoreCase("SAIDA")) {

            if (quantidade.compareTo(
                    equipamento.getQuantidadeDisponivel()) > 0) {

                throw new RuntimeException(
                    "A quantidade é maior que o estoque disponível.");
            }

            BigInteger estoqueDepoisDaSaida =
                equipamento.getQuantidadeDisponivel()
                    .subtract(quantidade);

            if (estoqueDepoisDaSaida.compareTo(
                    equipamento.getQuantidadeMinima()) < 0) {

                throw new RuntimeException(
                    "A saída não pode deixar o estoque abaixo da quantidade mínima.");
            }

            equipamento.setQuantidadeDisponivel(
                estoqueDepoisDaSaida
            );

        } else {

            throw new RuntimeException(
                "Tipo de movimentação inválido.");
        }

        er.save(equipamento);

        Movimentar movimentacao = new Movimentar();

        movimentacao.setTipo(tipo);
        movimentacao.setQuantidade(quantidade);
        movimentacao.setObservacao(observacao);
        movimentacao.setDataPedido(data_pedido);
        movimentacao.setDataInicio(data_inicio);
        movimentacao.setDataFim(data_fim);
        movimentacao.setUsuario(usuario);
        movimentacao.setEquipamento(equipamento);

        mr.save(movimentacao);

        return null;
    }
        
}
