package com.senai.backend.rental_eventos.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.senai.backend.rental_eventos.models.Equipamentos;
import com.senai.backend.rental_eventos.models.Movimentar;
import com.senai.backend.rental_eventos.services.EquipamentosService;
import com.senai.backend.rental_eventos.services.MovimentarService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/equipamentos")
public class EquipamentosController {
    
    private final EquipamentosService es;

    private final MovimentarService ms;

    public EquipamentosController(EquipamentosService es, MovimentarService ms) {
        this.es = es;
        this.ms = ms;
    }

    // Mostra a Tela de Cadastro dos Equipamentos
    @GetMapping("/cadastro")
    public String mostrarCadastro(Model model) {

        model.addAttribute("equipamento", new Equipamentos());

        return "cadastro";
    }

    // Salva o Equipamento
    @PostMapping("/cadastrar")
    public String cadastrar(
            @Valid @ModelAttribute("equipamento") Equipamentos equipamento, BindingResult result) {

        if (result.hasErrors()) {
            return "cadastro";
        }

        es.salvar(equipamento);

        return "redirect:/equipamentos";
    }

    // Lista os Equipamentos
    @GetMapping
    public String listar(
            @RequestParam(required = false) String busca, Model model) {

        List<Equipamentos> equipamentos;

        if (busca == null || busca.isBlank()) {
            equipamentos = es.listarTodos();
        } else {
            equipamentos = es.buscarPorNome(busca);
        }

        model.addAttribute("equipamentos", equipamentos);

        return "gestao";
    }
    
    // Mostra os detalhes do Equipamento
    @GetMapping("/detalhes/{id}")
    public String detalhes(@PathVariable Integer id, Model model) {
        
        Equipamentos equipamento = es.buscarPorId(id);
        
        List<Movimentar> movimentacoes = ms.listarPorEquipamento(id);

        model.addAttribute("equipamento", equipamento);
        model.addAttribute("movimentacoes", movimentacoes);

        return "equipamento";
    }

    // Abrir o equipamento para edição
    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Integer id, Model model) {

        Equipamentos equipamento = es.buscarPorId(id);

        model.addAttribute("equipamento", equipamento);

        return "cadastro";
    }

    // Atualizar os Equipamentos
    @PostMapping("/atualizar")
    public String atualizar(@ModelAttribute Equipamentos equipamentos) {
        
        es.salvar(equipamentos);

        return "redirect:/equipamentos";
    }

    // Excluir os Equipamentos
    @PostMapping("/excluir/{id}")
    public String excluir(@PathVariable Integer id) {

        es.excluir(id);

        return "redirect:/equipamentos";
    }
}
