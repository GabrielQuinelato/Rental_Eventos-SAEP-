package com.senai.backend.rental_eventos.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.senai.backend.rental_eventos.models.Usuario;
import com.senai.backend.rental_eventos.services.UsuarioService;

import jakarta.servlet.http.HttpSession;

@Controller
public class UsuarioController {
    
    private final UsuarioService us;

    public UsuarioController(UsuarioService us) {
        this.us = us;
    }

    @GetMapping("/login")
    public String mostrarLogin() {
        return "index";
    }

    @PostMapping("/login")
    public String login(
            @RequestParam String email,
            @RequestParam String senha,
            HttpSession session) {

        try {

            Usuario usuario = us.autenticar(email, senha);

            session.setAttribute("usuarioLogado", usuario);
            
            return "redirect:/home";

        } catch (RuntimeException e) {
            
            return "redirect:/login?error=" + e.getMessage();
        }

    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {

        session.invalidate();

        return "redirect:/login";
    }
}