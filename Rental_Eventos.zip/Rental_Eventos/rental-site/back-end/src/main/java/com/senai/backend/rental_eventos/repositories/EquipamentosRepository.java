package com.senai.backend.rental_eventos.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.senai.backend.rental_eventos.models.Equipamentos;

public interface EquipamentosRepository extends JpaRepository<Equipamentos, Integer> {
    
    public List<Equipamentos> findByNomeContainingIgnoreCase(String nome);

}
