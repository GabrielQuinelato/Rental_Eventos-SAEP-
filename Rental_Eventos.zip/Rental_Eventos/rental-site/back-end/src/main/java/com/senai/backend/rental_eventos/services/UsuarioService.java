package com.senai.backend.rental_eventos.services;

import org.springframework.stereotype.Service;

import com.senai.backend.rental_eventos.models.Usuario;
import com.senai.backend.rental_eventos.repositories.UsuarioRepository;

@Service
public class UsuarioService {
    
    private final UsuarioRepository ur;

    public UsuarioService(UsuarioRepository ur) {
        this.ur = ur;
    }

    public Usuario autenticar(String email, String senha) {

        Usuario usuario = ur
            .findByEmail(email)
            .orElseThrow(() -> 
                new RuntimeException("Usuário não encontrado")
            );

        if (!usuario.getSenha().equals(senha)) {
            throw new RuntimeException("Senha incorreta");
        }

        return usuario;
    }
}
